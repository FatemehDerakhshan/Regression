import matplotlib.pyplot as plt
plt.scatter()
plt.xlabel